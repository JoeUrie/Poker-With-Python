CIS 467 Term Project
Author: Joseph Urie

Attached in the term_project.zip is:
term_project.py - Source code for the machine, can test a customizable number of entries
test.py - A shorter source code that tests the entire dataset (1,000,000 entries) 
Both .csv datasets
The original proposal
The presentation power point file